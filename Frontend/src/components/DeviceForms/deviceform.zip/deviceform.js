import React, { useState } from "react";
import axios from "axios";
import "./deviceform.css";

const DeviceForm = () => {
  const [devices, setDevices] = useState([]);
  const [currentDeviceName, setCurrentDeviceName] = useState("");
  const [selectedDevice, setSelectedDevice] = useState("");
  const [attributeNames, setAttributeNames] = useState([]); // Initialize as an empty array
  const [currentAttributeName, setCurrentAttributeName] = useState("");
  const [currentHexAddress, setCurrentHexAddress] = useState("");
  const [hexAddresses, setHexAddresses] = useState({});
  const [deviceAttributes, setDeviceAttributes] = useState({});
  const [portNumber, setPortNumber] = useState(""); // New state for port number
  const [ipAddress, setIpAddress] = useState("");
  const [groupName, setGroupName] = useState(""); // New state for group name
  const [currentslaveId, setCurrentslaveId] = useState(""); // New state for slaveId
  const [minValue, setMinValue] = useState("");
  const [maxValue, setMaxValue] = useState("");

  const handleDeviceSelection = async (deviceName) => {
    setSelectedDevice(deviceName);

    if (!attributeNames[deviceName]) {
      setAttributeNames((prevAttributeNames) => ({
        ...prevAttributeNames,
        [deviceName]: [],
      }));

      setHexAddresses((prevHexAddresses) => ({
        ...prevHexAddresses,
        [deviceName]: {},
      }));
    }
  };

  const handleSubmit = async () => {
    try {
      if (!selectedDevice) {
        console.error("No device selected.");
        return;
      }

      const requestData = {
        devices: devices.map((device) => {
          const deviceData = {
            name: device.name,
            group: device.group, // Include group name
            slaveId: device.slaveId, // Include slaveId
            hexAddressInfo: attributeNames[device.name] || [],
            hexAddresses: hexAddresses[device.name] || {},
            portNumber: device.portNumber,
            ipAddress: device.ipAddress,
          };
          // Include min and max values for hexAddressInfo if they are defined
          if (deviceData.hexAddressInfo.length > 0) {
            deviceData.hexAddressInfo.forEach((attribute) => {
              if (typeof attribute.min !== "undefined") {
                attribute.min = attribute.min;
              }
              if (typeof attribute.max !== "undefined") {
                attribute.max = attribute.max;
              }
            });
          }

          return deviceData;
        }),
      };

      console.log("Request Data:", requestData);

      const response = await axios.post(
        "http://localhost:57541/api/v1/add-device/upload-json-data",
        requestData
      );
      alert("Form Submitted Successfully");
      console.log("Response:", response.data);
    } catch (error) {
      console.error("Error:", error.message);
    }
  };

  const handleDeleteDevice = () => {
    if (selectedDevice) {
      const updatedDevices = devices.filter(
        (device) => device.name !== selectedDevice
      );
      setDevices(updatedDevices);
      setSelectedDevice("");
      setCurrentDeviceName("");
    } else {
      // Display an alert if the currentDeviceName is empty
      alert("Select Device before deleting..");
    }
  };

  const handleAddAttributeName = () => {
    if (currentAttributeName.trim() !== "") {
      setAttributeNames((prevAttributeNames) => {
        const updatedAttributeNames = { ...prevAttributeNames };
        updatedAttributeNames[selectedDevice] = [
          ...(updatedAttributeNames[selectedDevice] || []),
          {
            parameterName: currentAttributeName,
            hexAddress: currentHexAddress,
            min: minValue, // Add min value
            max: maxValue, // Add max value
          },
        ];
        return updatedAttributeNames;
      });

      setHexAddresses((prevHexAddresses) => {
        const updatedHexAddresses = { ...prevHexAddresses };
        updatedHexAddresses[selectedDevice] = {
          ...updatedHexAddresses[selectedDevice],
          [currentAttributeName]: currentHexAddress,
        };
        return updatedHexAddresses;
      });

      // Clear the current attribute name and hexAddress
      setCurrentAttributeName("");
      setCurrentHexAddress("");
      setMinValue(""); // Clear min value
      setMaxValue(""); // Clear max value
    }
  };

  const handlePortNumberChange = (e) => {
    setPortNumber(e.target.value);
  };

  const handleIpAddressChange = (e) => {
    setIpAddress(e.target.value);
  };

  const handleslaveIdChange = (e) => {
    setCurrentslaveId(e.target.value);
  };

  const handleHexAddressChange = (deviceName, attributeName, hexAddress) => {
    setHexAddresses((prevHexAddresses) => ({
      ...prevHexAddresses,
      [deviceName]: {
        ...prevHexAddresses[deviceName],
        [attributeName]: hexAddress,
      },
    }));
    setCurrentHexAddress(hexAddress);
  };

  const handleAddDevice = () => {
    if (
      currentDeviceName.trim() !== "" &&
      currentslaveId.trim() !== "" // Ensure slaveId is provided
    ) {
      const newDevice = {
        name: currentDeviceName,
        group: groupName, // Include group name
        slaveId: currentslaveId, // Include slaveId
        hexAddressInfo: [],
        portNumber: portNumber,
        ipAddress: ipAddress,
      };
      setDevices([...devices, newDevice]);

      setDeviceAttributes((prevAttributes) => ({
        ...prevAttributes,
        [currentDeviceName]: [],
      }));

      setCurrentDeviceName("");
      setPortNumber("");
      setIpAddress("");
      setGroupName("");
      setCurrentslaveId(""); // Clear slaveId after adding the device
    }
  };

  const handleDeleteAttribute = () => {
    if (selectedDevice && currentAttributeName.trim() !== "") {
      setAttributeNames((prevAttributeNames) => {
        const updatedAttributeNames = { ...prevAttributeNames };
        updatedAttributeNames[selectedDevice] = (
          updatedAttributeNames[selectedDevice] || []
        ).filter(
          (attribute) => attribute.parameterName !== currentAttributeName
        );
        return updatedAttributeNames;
      });

      setHexAddresses((prevHexAddresses) => {
        const updatedHexAddresses = { ...prevHexAddresses };
        delete updatedHexAddresses[selectedDevice][currentAttributeName];
        return updatedHexAddresses;
      });

      // Clear the current attribute name and hexAddress
      setCurrentAttributeName("");
      setCurrentHexAddress("");
    } else {
      // Display an alert if either selectedDevice is not set or the currentAttributeName is empty
      alert("Select a device and type an attribute name before deleting.");
    }
  };

  return (
    <section id="wrapper">
      <Navbar />
      <div className="device-form">
      <h2>Device Form</h2>
      <div>
        <label>
          Device Name:
          <input
            type="text"
            className="input-field"
            value={currentDeviceName}
            onChange={(e) => setCurrentDeviceName(e.target.value)}
          />
        </label>
        <label>
          Group Name:
          <input
            type="text"
            className="input-field"
            value={groupName}
            onChange={(e) => setGroupName(e.target.value)}
          />
        </label>
        <label bold-label>
          Port Number:
          <input
            type="number"
            className="input-field"
            value={portNumber}
            placeholder="0"
            onChange={handlePortNumberChange}
            min="0"
          />
        </label>

        <label bold-label>
          IP Address:
          <input
            type="text"
            className="input-field"
            value={ipAddress}
            placeholder="0"
            onChange={handleIpAddressChange}
            min="0"
          />
        </label>
        <label bold-label>
          Slave ID:
          <input
            type="number"
            className="input-field"
            value={currentslaveId}
            placeholder="0"
            onChange={handleslaveIdChange}
            min="0"
          />
        </label>
        <div className="button-container">
          <div className="flex-container">
            <button
              className="add-button label-field"
              onClick={handleAddDevice}
            >
              Add Device
            </button>
            {selectedDevice && (
              <>
                <button
                  className="add-button label-field"
                  onClick={handleDeleteDevice}
                >
                  Delete Device
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {devices.length > 0 && (
        <div>
          <label className="label-field bold-label">
            Select Device:
            <select
              className="input-field"
              value={selectedDevice}
              onChange={(e) => handleDeviceSelection(e.target.value)}
            >
              <option value="">Select a device</option>
              {devices.map((device, index) => (
                <option key={index} value={device.name}>
                  {device.name}
                </option>
              ))}
            </select>
          </label>

          {selectedDevice && (
            <div>
              <label bold-label>
                Attribute Name:
                <input
                  type="text"
                  className="input-field"
                  value={currentAttributeName}
                  onChange={(e) => setCurrentAttributeName(e.target.value)}
                />
              </label>
              <br />
              <label bold-label>
                Hex Address:
                <input
                  type="text"
                  className="input-field"
                  value={
                    hexAddresses[selectedDevice]?.[currentAttributeName] || ""
                  }
                  onChange={(e) =>
                    handleHexAddressChange(
                      selectedDevice,
                      currentAttributeName,
                      e.target.value
                    )
                  }
                />
              </label>
              <br />
              {/* Inside the return statement */}
              <label bold-label>
                Min Value:
                <input
                  type="number"
                  className="input-field"
                  value={minValue}
                  onChange={(e) => setMinValue(e.target.value)}
                  placeholder="0"
                  min="0"
                />
              </label>

              <label bold-label>
                Max Value:
                <input
                  type="number"
                  className="input-field"
                  value={maxValue}
                  onChange={(e) => setMaxValue(e.target.value)}
                  placeholder="0"
                  min="0"
                />
              </label>

              <div className="flex-container button-container">
                <button
                  className="add-button label-field"
                  onClick={handleAddAttributeName}
                >
                  Add Attribute
                </button>

                <button
                  className="add-button label-field"
                  onClick={handleDeleteAttribute}
                >
                  Delete Attribute
                </button>
              </div>
              <div>
                <div>
                  <div>
                    <label className="bold-label">
                      Device hexAddressInfo:
                      <ul className="no-list-style label-field">
                        {attributeNames[selectedDevice] &&
                          attributeNames[selectedDevice].map(
                            (attribute, index) => (
                              <li key={index}>
                                Attribute Name: {attribute.parameterName}{" "}
                                &emsp;Hex Address: {attribute.hexAddress}{" "}
                                &emsp;Min Value: {attribute.min} &emsp;Max
                                Value: {attribute.max}
                              </li>
                            )
                          )}
                      </ul>
                    </label>
                  </div>
                </div>
              </div>
            </div>
          )}
          <div className="button-container">
            <button className="add-button label-field" onClick={handleSubmit}>
              Submit
            </button>
          </div>
        </div>
      )}
    </div>
    </section>
  );
};

export default DeviceForm;